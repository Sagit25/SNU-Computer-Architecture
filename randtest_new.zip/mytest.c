#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "auxs.h"
extern SFP16 fpadd(SFP16 x, SFP16 y);

SFP16 g()
{
    int hi, lo;
    hi = rand() & 0xff;
    lo = rand() & 0xff;
    return (SFP16)((hi << 8) + lo);
}

SFP16 f(SFP16 x, SFP16 y)
{
    return float_sfp16(
        sfp16_float(x) + sfp16_float(y)
    );
}

SFP16 _fpcmp(SFP16 x, SFP16 y)
{
    SFP16 a_x, a_y;

    a_x = (x & 0x7fff);
    a_y = (y & 0x7fff);

    if (a_x == a_y)
    {
        if (x == y)
            return 1;   // right answer
        else if (a_x == 0)
            return 1;   // +0.0 == -0.0
        else if (a_x == 0x7f01)
            return 1;   // We do not distinguish
                        // between +NaN and -NaN
        else
            return 0;   // wrong answer
    }
    else
        return 0;       // For NaN, we only allow
                        // the bit pattern where
                        // the fraction part is
                        // 0b00000001
}

int main(void)
{
    int correct = 0, wrong = 0;

    srand(time(NULL));

    printf("== 100000 FP TEST ==\n");
    printf("(WRONG CASES):\n");

    for (int i = 0; i < 100000; i++)
    {
        SFP16 a, b, c, d;

        a = g(), b = g();
        c = fpadd(a, b);
        d = f(a, b);

        if (_fpcmp(c, d))
        {
            correct += 1;
        }
        else
        {
            wrong += 1;
            printf("%04x %04x ! %04x %04x\n", a, b, c, d);
        }

        // printf("%04x %04x %04x %04x\n", a, b, c, d);
    }

    printf("CORRECT:   WRONG:\n");
    printf(" %06d   %06d\n", correct, wrong);

    return 0;
}