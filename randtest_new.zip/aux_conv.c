#include "auxs.h"

float sfp16_float(SFP16 x) {
    union
    {
        SFP16 f;
        struct {
            unsigned int m : 8;
            unsigned int e : 7;
            signed int s : 1;
        } b;
    } bin;

    union
    {
        float f;
        struct {
            unsigned int m : 23;
            unsigned int e : 8;
            signed int s : 1;
        } b;
    } res;

    int m, e;

    bin.f = x;
    res.b.s = bin.b.s;
    if (bin.b.e == 0x7f)
    {
        res.b.e = 0xff;
        res.b.m = bin.b.m;
    }
    else if (bin.b.e)
    {
        res.b.e = bin.b.e + 64;
        res.b.m = bin.b.m << 15;
    }
    else
    {
        if (!bin.b.m)
        {
            res.b.e = 0;
            res.b.m = 0;
        }
        else
        {
            e = 64, m = bin.b.m;
            while (!(m & 0x80)) m *= 2, e--;
            m += m;
            res.b.e = e;
            res.b.m = m << 15;
        }
    }

    return res.f;
}

SFP16 float_sfp16(float x)
{
    union
    {
        float f;
        struct {
            unsigned int m : 23;
            unsigned int e : 8;
            signed int s : 1;
        } b;
    } bin;

    union
    {
        SFP16 f;
        struct {
            unsigned int m : 8;
            unsigned int e : 7;
            signed int s : 1;
        } b;
    } res;

    int m, e;

    bin.f = x;
    res.b.s = bin.b.s;
    if (bin.b.e == 0xff)
    {
        res.b.e = 0x7f;
        res.b.m = !!(bin.b.m);
    }
    else
    {
        e = bin.b.e - 64, m = bin.b.m;
        if (e < -8) e ^= e, m ^= m;
        else if (e <= 0)
        {
            m += 0x800000; m >>= -e;
            if ((m & 0x8000) && ((m & 0x10000) || (m & 0x7fff)))
                m += 0x8000;
            if (m & 0x1000000) m /= 2, e++;
            if (e > 0) e = 1, m ^= m;
            else e ^= e, m /= 2;
        }
        else
        {
            if ((m & 0x4000) && ((m & 0x8000) || (m & 0x3fff)))
                m += 0x8000;
            if (m & 0x800000) m ^= m, e++;
        }

        if (e >= 0x7f)
        {
            res.b.e = 0x7f;
            res.b.m = 0;
        }
        else
        {
            res.b.e = e;
            res.b.m = m >> 15;
        }
    }

    return res.f;
}