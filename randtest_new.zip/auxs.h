#ifndef _AUXS_H
#define _AUXS_H

typedef unsigned short SFP16;

float sfp16_float(SFP16);
SFP16 float_sfp16(float);

#endif